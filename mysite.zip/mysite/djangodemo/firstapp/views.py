from django.shortcuts import render

# Create your views here.

def index(request):
	return render(request,'firstapp/index.html')

def about(request):
	return render(request,'firstapp/about.html')

def services(request):
	return render(request,'firstapp/services.html')

def dropdown(request):
	return render(request,'firstapp/dropdown.html')

def contact(request):
	return render(request,'firstapp/contact.html')